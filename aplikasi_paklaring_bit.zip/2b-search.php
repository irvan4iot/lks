<?php
// (A) CONNECT TO DATABASE
// ! CHANGE SETTINGS TO YOUR OWN !
$dbhost = '127.0.0.1';
$dbname = 'paklaring';
$dbchar = 'utf8';
$dbuser = 'root';
$dbpass = '';
$pdo = new PDO(
	"mysql:host=$dbhost;dbname=$dbname;charset=$dbchar", 
  $dbuser, $dbpass
);

// (B) DO SEARCH
$data = [];
switch ($_POST['type']) {
  // (B1) INVALID SEARCH TYPE
  default: break;

  // (B2) SEARCH FOR USER NAME (SINGLE FIELD AUTOCOMPLETE)
  case "nama_instansi":
    $stmt = $pdo->prepare("SELECT id_instansi,nama_instansi FROM `instansi` WHERE nama_instansi LIKE ?");
    $stmt->execute(["%" . $_POST['search'] . "%"]);
    while ($row = $stmt->fetch()) { $data[] = $row['nama_instansi']; }
    break;

  // (B3) SEARCH BY USER EMAIL (MULTIPLE FIELDS AUTOCOMPLETE)
  case "email":
    $stmt = $pdo->prepare("SELECT * FROM instansi WHERE `email` LIKE ?");
    $stmt->execute(["%" . $_POST['search'] . "%"]);
    while ($row = $stmt->fetch(PDO::FETCH_NAMED)) { 
      $data[] = [
        "D" => $row['email'],
        "dName" => $row['name'],
        "dTel" => $row['phone']
      ]; 
    }
    break;
}

// (C) RETURN RESULTS
if (count($data)==0) { $data = null; }
echo json_encode($data);
$stmt = null;
$pdo = null;