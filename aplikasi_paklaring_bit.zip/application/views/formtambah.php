

<?php
	defined('BASEPATH') OR exit('Akses langsung tidak diperbolehkan');
	//echo validation_errors();
?>
<link rel="stylesheet" href="1.css">
    <script src="1.js"></script>
<section class="container-fluid">
	<div class="row">
		<div class="form-input clearfix">
			<div class="col-md-12">
				
				<?php
					if(isset($_SESSION['input_sukses']))
					{
				?>
						<div class="alert alert-success">
							<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
						  	<strong>Sukses!</strong> <?php echo $_SESSION['input_sukses']; ?>
						</div>
				<?php
					}
				?>

				<div class="panel panel-primary">
					<div class="panel-heading">Tambah Data Paklaring | <h1>Selamat datang "<?php echo $this->session->userdata('nama'); ?>"</h1></div>
					<div class="panel-body">
						<!-- <form action="<?php //echo base_url('home/tambahmobil'); ?>" method="post" class="form-horizontal"> -->
						
						<?php echo form_open('home/tambahpaklaring', ['class' => 'form-horizontal', 'method' => 'post']); ?>
						

							<div class="form-group">
								<label for="jenis" class="control-label col-sm-2">Nama Instansi </label>
								<div class="col-sm-10">
									<!-- (B) CREATE INPUT FIELDS -->
   
    <input class="form-control" type="text" id="nama_instansi" name="nama_instansi" required/><br><br>

   
    <script>
    // (C) ATTACH AUTOCOMPLETE TO INPUT FIELDS
    window.addEventListener("DOMContentLoaded", function(){
      ac.attach({
        target: "nama_instansi",
        data: "<?php echo base_url('2b-search.php'); ?>",
        post: { type: "nama_instansi" }
      });
      
      ac.attach({
        target: "demoB",
        data: "2b-search.php",
        post: { type: "email" },
        // OPTIONAL
        delay : 1000,
        min : 5
      });
    });
    </script>



								</div>
							</div>

							<div class="form-group">
								<label for="tahun" class="control-label col-sm-2">Operator </label>
								<div class="col-sm-10">
									 <select class="form-control" id="sel1" name="operator">
    									
    									<option selected="selected">Muhdi</option>
   	 									<option>Deny</option>
    									<option>Diani</option>
    									<option>Kintan</option>
    									<option>Futri</option>
    									<option>Ikmal</option>
  									</select>
									<?php echo form_error('tahun'); ?>
								</div>
							</div>

							<div class="form-group">
								<label for="nama_pekerjaan" class="control-label col-sm-2">Nama Pekerjaan </label>
								<div class="col-sm-10">
									<textarea class="form-control" rows="5" id="comment" name="nama_pekerjaan" required></textarea>
									<?php echo form_error('harga'); ?>
								</div>
							</div>

							<div class="form-group">
								<label for="nopol" class="control-label col-sm-2">Tanggal Mulai</label>
								<div class="col-sm-10">
									<input type="date" class="form-control" name="tanggal_mulai" value="<?php echo set_value('nopol'); ?>" required>
									<?php echo form_error('nopol'); ?>
								</div>
							</div>
							<div class="form-group">
								<label for="nopol" class="control-label col-sm-2">Tanggal Berakhir</label>
								<div class="col-sm-10">
									<input type="date" class="form-control" name="tanggal_berakhir" value="<?php echo set_value('nopol'); ?>" required>
									<?php echo form_error('nopol'); ?>
								</div>
							</div>
							<div class="form-group">
								<label for="nopol" class="control-label col-sm-2">Jabatan Tenaga Ahli</label>
								<div class="col-sm-10">
								<?php

									$query_jabatan=$this->db->query("SELECT * FROM jabatan")->result();
									foreach($query_jabatan as $list_jabatan)
									{
										
									?>
										
									<div class="row-sm-10 div1">
									
										<div class="row-sm-10 ">


											<?php echo $list_jabatan->nama_jabatan; ?> <input   type="checkbox"name="jabatan[]" value="<?php echo $list_jabatan->id_jabatan; ?>" > 
										</div>

									</div>
									
									
									<?php } ?>
							
									<?php echo form_error('nopol'); ?>
								</div>
							</div>
							<div class="form-group">
								<label for="nopol" class="control-label col-sm-2">Lokasi File</label>
								<div class="col-sm-10">
									<input type="text" class="form-control" name="lokasi_file" value="<?php echo set_value('nopol'); ?>" required>
									<?php echo form_error('nopol'); ?>
								</div>
							</div>
							<div class="form-group">
								<div class="btn-form col-sm-12">
									<a href="<?php echo base_url('home/lihatdata'); ?>"><button type="button" class='btn btn-default'>Batal</button></a>
									<button type="submit" class='btn btn-primary'>Simpan</button>
								</div>
							</div>
						<?php echo form_close(); ?>

					</div>
				</div>
			</div>
		</div>
	</div>
</section>