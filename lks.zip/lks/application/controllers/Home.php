<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Home extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('mobil_model');
		$this->load->helper(['url_helper', 'form']);
    	$this->load->library(['form_validation', 'session']);
	}
 	public function login(){
 		//echo "ini Kontroller Login";die();
 		//$this->load->library('session');
    	$username = $this->input->post('username'); // Ambil isi dari inputan username pada form login
    	$password = $this->input->post('password'); // Ambil isi dari inputan password pada form login dan encrypt dengan md5
    	$usercheck = $this->getusername($username);
    	echo($username)."<br>"; // Panggil fungsi get yang ada di UserModel.php
    	echo($password)."<br>";
    	echo($usercheck->num_rows())."<br>";
    	foreach ($usercheck->result() as $user )
    	{
    
    	}
    	echo "Password adalah ".$user->password;
    	//die();
    	if(empty($user))
    	{ // Jika hasilnya kosong / user tidak ditemukan
      		$this->session->set_flashdata('message', 'Username tidak ditemukan'); // Buat session flashdata
      		redirect('home'); // Redirect ke halaman login
    	}
    	else
    	{
      		if($password == $user->password)
      		{ // Jika password yang diinput sama dengan password yang didatabase
        		$session = array(
          		'authenticated'=>true, // Buat session authenticated dengan value true
          		'username'=>$user->username,  // Buat session username
          		'nama'=>$user->nama // Buat session authenticated
        		);
        		$this->session->set_userdata($session); // Buat session sesuai $session
        		//redirect('home/lihatdata'); // Redirect ke halaman welcome
        		echo "username dan Password benar <br>";
        		print_r($this->session->userdata);
        		//die();
        			redirect('home/lihatdata'); 

      		}

      		else
      		{
        		$this->session->set_flashdata('message', 'Password salah'); // Buat session flashdata
        		redirect('home/'); // Redirect ke halaman login
      		}
    	}
  	}
  public function logout(){
    $this->session->sess_destroy(); // Hapus semua session
    redirect('home'); // Redirect ke halaman login
  }
	public function index()
	{
		 $this->load->library('session');	
		
		if($this->session->userdata('authenticated')) // Jika user sudah login (Session authenticated ditemukan)
      	redirect('home/lihatdata'); // Redirect ke page welcome
    	$this->load->view('login'); // Load view login.php
		//redirect('home/lihatdata');
	}

	public function getusername($username){
        return $this->db->query("SELECT * FROM user WHERE username='$username'");
    }
	
	public function carinip()
	{
		$data['database'] = $this->mobil_model->get_all_data();

		$data['title'] = "Halaman Data Paklaring";

		$this->load->view('templates/header', $data);
		$this->load->view('tampildata', $data);
		$this->load->view('templates/footer');
	}
	public function lihatdata()
	{
		 //$this->load->library('session');
		 	//echo "ini adalah halaman Controller lihatdata";
		 	//print_r($this->session->userdata);die();
		if($this->session->userdata('authenticated'))
			{

			 // Jika user sudah login (Session authenticated ditemukan)
      		//redirect('home/lihatdata'); // Redirect ke page welcome
			$data['database'] = $this->mobil_model->get_all_data();

			$data['title'] = "Halaman Data Paklaring";

			$this->load->view('templates/header', $data);
			$this->load->view('tampildata', $data);
			$this->load->view('templates/footer');
		}
		else
		{
			$this->load->view('login'); // Load view login.php
		}

	}

	public function formtambah()
	{
		if($this->session->userdata('authenticated'))
		{
	
			$data['title'] = "Tambah Data | Test tampil Database";
			$this->load->view('templates/header', $data);
			$this->load->view('formtambah');
			$this->load->view('templates/footer');
		}
		else
		{
			$this->load->view('login');
		}
		
	}

	public function formcari()
	{
		if($this->session->userdata('authenticated'))
		{
	
			$data['title'] = "Cari Data | Pencarian Paklaring";
			$this->load->view('templates/header', $data);
			$this->load->view('formcari');
			$this->load->view('templates/footer');
		}
		else
		{
			$this->load->view('login');
		}
		
	}
	
	public function submitcari()
	{
		if($this->session->userdata('authenticated'))
			{
		
			$nama_instansi=$this->input->post('nama_instansi',TRUE);
			$not_perusahaan1=$this->input->post('not_perusahaan1',TRUE);
			$not_perusahaan2=$this->input->post('not_perusahaan2',TRUE);
			$not_perusahaan3=$this->input->post('not_perusahaan3',TRUE);
			$perusahaan1=$this->input->post('perusahaan1',TRUE);
			$perusahaan2=$this->input->post('perusahaan2',TRUE);
			$perusahaan3=$this->input->post('perusahaan3',TRUE);
			$tanggal_mulai=$this->input->post('tanggal_mulai',TRUE);
			$tanggal_berakhir=$this->input->post('tanggal_berakhir',TRUE);  
			
			$q_check_instansi=$this->db->query("SELECT * FROM instansi where nama_instansi='$nama_instansi'");
			//echo $q_check_instansi->num_rows();

			if ($q_check_instansi->num_rows()>0) 
			{
				//echo "lebih dari satu goblog <br>";
				foreach($q_check_instansi->result() as $q_id_instansi)
				{
					$id_instansi=$q_id_instansi->id_instansi;
				}
				//echo "ID Instansi :".$id_instansi."<br>";
				//echo "nama_instansi :".$nama_instansi."<br>";
				//echo "not_perusahaan1 :".$not_perusahaan1."<br>";
				//echo "not_perusahaan2 :".$not_perusahaan2."<br>";
				//echo "not_perusahaan3 :".$not_perusahaan3."<br>";
				//echo "perusahaan1 :".$perusahaan1."<br>";
				//echo "perusahaan2 :".$perusahaan2."<br>";
				//echo "perusahaan3 :".$perusahaan3."<br>";
				//echo "tanggal_mulai :".$tanggal_mulai."<br>";
				//echo "tanggal_berakhir :".$tanggal_berakhir."<br>";
				if ($not_perusahaan1!=="1001" or $not_perusahaan2!=="1002" or $not_perusahaan3!=="1003")
				{
					$final_query=$this->db->query("SELECT * FROM v_paklaring WHERE id_instansi='$id_instansi' AND  id_perusahaan NOT IN('$not_perusahaan1','$not_perusahaan2','$not_perusahaan3') AND (tanggal_mulai BETWEEN '$tanggal_mulai' AND '$tanggal_berakhir') ORDER BY tanggal_mulai DESC")->result();
				}
				if ($perusahaan1!=="1001" or $perusahaan2!=="1002" or $perusahaan3!=="1003")
				{
					$final_query=$this->db->query("SELECT * FROM v_paklaring WHERE id_instansi='$id_instansi' AND  id_perusahaan IN('$perusahaan1','$perusahaan2','$perusahaan3') AND (tanggal_mulai BETWEEN '$tanggal_mulai' AND '$tanggal_berakhir') ORDER BY tanggal_mulai DESC")->result();
				}
				//print_r($final_query);
			}
			else
			{
				//echo "not_perusahaan1 :".$not_perusahaan1."<br>";
				//echo "not_perusahaan2 :".$not_perusahaan2."<br>";
				//echo "not_perusahaan3 :".$not_perusahaan3."<br>";
				//echo "perusahaan1 :".$perusahaan1."<br>";
				//echo "perusahaan2 :".$perusahaan2."<br>";
				//echo "perusahaan3 :".$perusahaan3."<br>";
				//echo "tanggal_mulai :".$tanggal_mulai."<br>";
				//echo "tanggal_berakhir :".$tanggal_berakhir."<br>";
				if ($not_perusahaan1!=="1001" or $not_perusahaan2!=="1002" or $not_perusahaan3!=="1003")
				{
					$final_query=$this->db->query("SELECT * FROM v_paklaring WHERE id_perusahaan NOT IN('$not_perusahaan1','$not_perusahaan2','$not_perusahaan3') AND (tanggal_mulai BETWEEN '$tanggal_mulai' AND '$tanggal_berakhir') ORDER BY tanggal_mulai DESC")->result();
				}
				if ($perusahaan1!=="2001" or $perusahaan2!=="2002" or $perusahaan3!=="2003")
				{
					$final_query=$this->db->query("SELECT * FROM v_paklaring WHERE id_perusahaan IN('$perusahaan1','$perusahaan2','$perusahaan3') AND (tanggal_mulai BETWEEN '$tanggal_mulai' AND '$tanggal_berakhir') ORDER BY tanggal_mulai DESC")->result();
				}
			}
			//print_r($final_query);die();
			$data['database']=$final_query;

			//die();
			$this->load->view('templates/header', $data);
			$this->load->view('hasilpencarian', $data);
			$this->load->view('templates/footer');
			
			
			
			
			
			$this->session->set_flashdata('input_sukses','Data bergasil Paklaring berhasil di input');
			//die();
			//redirect('home/lihatdata');
		}
		else
		{
			$this->load->view('login'); // Load view login.php
		}
	}

	public function tambahpaklaring()
	{
		if($this->session->userdata('authenticated'))
			{
		
			$nama_instansi=$this->input->post('nama_instansi',TRUE);
			$operator=$this->input->post('operator',TRUE); 
			$nama_pekerjaan=$this->input->post('nama_pekerjaan',TRUE); 
			$tanggal_mulai=$this->input->post('tanggal_mulai',TRUE);
			$tanggal_berakhir=$this->input->post('tanggal_berakhir',TRUE);  
			$lokasi_file=$this->input->post('lokasi_file',TRUE);
			$jabatan = $this->input->post('jabatan');
			$id_perusahaan = $this->input->post('id_perusahaan');



			print_r($nama_instansi);echo "<br>";
			print_r($operator);echo "<br>";
			print_r($nama_pekerjaan);echo "<br>";
			print_r($tanggal_mulai);echo "<br>";
			print_r($tanggal_berakhir);echo "<br>";
			print_r($lokasi_file);echo "<br>";
			print_r($id_perusahaan);echo "<br>";
			//die();
			//$str = str_replace("", , $str);
			$newstr = str_replace('\\','\\\\',$lokasi_file);
				print_r($newstr);echo "<br>";
			
			
			$q_check_instansi=$this->db->query("SELECT * FROM instansi where nama_instansi='$nama_instansi'");
			echo $q_check_instansi->num_rows();
			$q_check_id_pekerjaan=$this->db->query("SELECT id_pekerjaan FROM pekerjaan ORDER BY id_pekerjaan DESC LIMIT 1;");
			foreach($q_check_id_pekerjaan->result() as $r_id_pekerjaan)
			{
				$id_last_pekerjaan=$r_id_pekerjaan->id_pekerjaan+1;
			}
			echo "<br>ID Pekerjaan terakhir = ".$r_id_pekerjaan->id_pekerjaan."<br>";
			echo "<br>ID Pekerjaan terakhir + 1 = ".$id_last_pekerjaan."<br>";
			//die();
			if ($q_check_instansi->num_rows()>0)
			{
				foreach($q_check_instansi->result() as $q2)
				{
					$id_instansi=$q2->id_instansi;
					
				}
				echo "<br>ID Instansi terakhir = ".$id_instansi;
				
				$insert_pekerjaan=$this->db->query("INSERT INTO pekerjaan(id_pekerjaan,id_instansi,operator,nama_pekerjaan,tanggal_mulai,tanggal_berakhir,lokasi_file,id_perusahaan) VALUES ('$id_last_pekerjaan','$id_instansi','$operator','$nama_pekerjaan','$tanggal_mulai','$tanggal_berakhir','$newstr','$id_perusahaan')");

				
			}
			else
			{
				$q_check_id_instansi=$this->db->query("SELECT id_instansi FROM instansi ORDER BY id_instansi DESC LIMIT 1;");
				foreach($q_check_id_instansi->result() as $q3)
				{
					$id_instansi_last=$q3->id_instansi+1;
				}
				$insert_instansi=$this->db->query("INSERT INTO instansi(id_instansi,nama_instansi) VALUES ($id_instansi_last,'$nama_instansi')");
				$insert_pekerjaan2=$this->db->query("INSERT INTO pekerjaan(id_pekerjaan,id_instansi,operator,nama_pekerjaan,tanggal_mulai,tanggal_berakhir,lokasi_file,id_perusahaan) VALUES ('$id_last_pekerjaan','$id_instansi_last','$operator','$nama_pekerjaan','$tanggal_mulai','$tanggal_berakhir','$newstr','$id_perusahaan')");
			}
			//die();
			foreach($jabatan as $selected)
			{
				$insert_trx_jabatan_pekerjaan=$this->db->query("INSERT INTO trx_jabatan_pekerjaan(id_jabatan,id_pekerjaan) VALUES ('$selected','$id_last_pekerjaan')");
			}
			
			
			$this->session->set_flashdata('input_sukses','Data bergasil Paklaring berhasil di input');
			//die();
			redirect('home/lihatdata');
		}
		else
		{
			$this->load->view('login'); // Load view login.php
		}
	}




	public function hapusdata($id)
	{
		$this->mobil_model->hapus_mobil($id);
		$this->session->set_flashdata('hapus_sukses','Data Paklaring berhasil di hapus');
		redirect('/home/lihatdata');
	}


	public function hapuspekerjaan($id)
	{	
		echo $id;
		$this->db->query("DELETE FROM trx_jabatan_pekerjaan WHERE id_pekerjaan = '$id'");
		$this->db->query("DELETE FROM pekerjaan WHERE id_pekerjaan = '$id'");


		$this->session->set_flashdata('hapus_sukses','Data Instansi berhasil di hapus');
		redirect('/home/lihatdata');
	}

	public function formedit($id)
	{
		$data['title'] = 'Edit Data | Test tampil Database';

		$data['db'] = $this->mobil_model->edit_mobil($id);

		$this->load->view('templates/header', $data);
		$this->load->view('formedit', $data);
		$this->load->view('templates/footer');
	}

	public function updatemobil($id)
	{
		$this->validasi();

		if($this->form_validation->run() === FALSE)
		{
			$this->formedit($id);
		}
		else
		{
			$this->mobil_model->update_mobil();
			$this->session->set_flashdata('update_sukses', 'Data mobil berhasil diperbaharui');
			redirect('/home/lihatdata');
		}
	}

	public function validasi()
	{
		$this->form_validation->set_message('required', '{field} tidak boleh kosong');

		$config = [[
					'field' => 'jenis',
					'label' => 'Jenis',
					'rules' => 'required'
				],
				[
					'field' => 'tahun',
					'label' => 'Tahun',
					'rules' => 'required'
				],
				[
					'field' => 'harga',
					'label' => 'Harga',
					'rules' => 'required'
				],
				[
					'field' => 'nopol',
					'label' => 'No. Polisi',
					'rules' => 'required'
				]];

		$this->form_validation->set_rules($config);
	}
}
?>